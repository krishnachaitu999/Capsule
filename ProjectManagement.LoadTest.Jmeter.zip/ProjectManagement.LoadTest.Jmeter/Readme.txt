1. Install Jmeter in loacal.
2. Open the "jmeter.bat" file under the "bin" folder. JMeter tool opens.

3. Under File -> Open -> (browse to the "ProjectManagement.LoadTest.Jmeter.jmx" Test Plan kept under the "Test Plan" folder"). 
   500 concurrent users for 10 minutes is already set up in the Test Plan.

4. Click on "Start" button and wait for 10 minutes.
5. The "ProjectManagement_LoadTesting_SummaryReport.csv" and "ProjectManagement_Load_Testing_Screenshots.docx" are available under "Reports" folder.
