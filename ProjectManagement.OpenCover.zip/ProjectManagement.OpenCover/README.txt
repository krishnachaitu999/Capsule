To Run OpenCover:
1.Go To Tools -> Extensions and Updates.
2. Search for OpenCover UI.
3. Double click and install the tool.
4. Now restart the visual studio and openCover will appear under menu.
5. Now Go to Test -> Windows -> Test Explorer
6. Now Click on run all Link
7. Now Open OpenCover -> OpenCover Test Explorer
8.Click on TEsts Cover with Open Cover.
9.Now you can able to see the results in OpenCover Results.

