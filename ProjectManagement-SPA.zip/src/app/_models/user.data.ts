export interface UserData {
    User_ID: number;
    FirstName: string;
    LastName: string;
    Employee_ID: number;
    Project_ID: number;
    Task_ID: number;
}