***************ProjectManagement Performance Tests using NBench***************
1. The performance test has been set up using NBench and is run using NBench.Runner.
2. Before running the test, make sure the "ProjectManagement.sln" file is built so that all the necessary packages are downloaded. All the projects should be compiled.
3. I have used the NUnit tests as benchmark hence the NUnit project(ProjectManagement.NUnitTests) should be compiled.
4. To run the performance test, double-click on the "PerformanceTestRunner.bat" file.
5. The performance test report would be generated.